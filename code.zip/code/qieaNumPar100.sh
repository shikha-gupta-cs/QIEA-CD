 #!/bin/bash         


cat <<EOF > parameter4.h
#define N 100
#define filename "data//100_4adj.txt"
#define filenameB "B//100_4adjB.txt"
#define filenameDeg "Deg//100_4adjDeg.txt"
#define mutRate 0.3
#define popSize 15
#define maxGenerations 3000
#define maxTxPerBlk 128
#define alpha 0.01
#define beta 0.005
#define nc 10
const float theta1 =0.095;
const float theta2 =0.0058;
EOF

/usr/local/cuda-8.0/bin/nvcc -rdc=true -lcudadevrt -arch=sm_35 -o qiea100 qieaNumChromosome.cu -lineinfo

./qiea100
 
