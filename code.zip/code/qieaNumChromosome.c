#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>

    double **chromosomes, **best_quantum, **b_matrix, fitness_val, theta1,theta2,alpha,beta,mutRate;
	int **classical_pop, **input_graph, *indegree,*outdegree, *best_classical, *tempChromosome;
	int noOfChromosomes,no_mut=0;
	int noOfNodes,noOfEdges,nc;
	int generations,no_gen=0;

double random_real()
{
    return (double)rand() / (double)RAND_MAX ;
}

double obj_func(int n)
{
	//printf("\n in obj with %d\n",n);
	int i,j;
	double ntwk_mod = 0;
	for(i=0;i<noOfNodes;i++)
      for(j=0;j<noOfNodes;j++)
	  {
	  	if(n < 0)
	  	{
	  	   if(best_classical[i] == best_classical[j])
	  	     // ntwk_mod = ntwk_mod + input_graph[i][j] - (degree[i]*degree[j])/(double)(2*noOfEdges);
	  	      ntwk_mod = ntwk_mod + b_matrix[i][j];
	    }
	    else
	    {
	    	if(classical_pop[n][i] == classical_pop[n][j])
	  	     //ntwk_mod = ntwk_mod + input_graph[i][j] - (degree[i]*degree[j])/(double)(2*noOfEdges);
	  	     ntwk_mod = ntwk_mod + b_matrix[i][j];
	    }
	  }	  
	
	return ntwk_mod/(double)(noOfEdges);
	//return ntwk_mod/(double)(2*noOfEdges);
}
void initialize()
{
	int i,j,rows,columns;
	rows=nc*noOfChromosomes;
	columns=noOfNodes;
	//printf("\n   rows %d  col %d \n",rows,columns);
	//int **chromosomes;
	chromosomes =(double**)malloc(rows * sizeof(double *));
	for(i = 0; i < rows; i++) 
	{
	    chromosomes[i] =(double*) malloc(columns* sizeof(double));
	
	}
	//initializing chromosomes array
	double ncSqrt=sqrt(nc);
	for(i=0;i<rows;++i)
	{
		for(j=0;j<columns;++j)
		{
			chromosomes[i][j]=1/ncSqrt;
		}
	}
	
	classical_pop =(int**)malloc(noOfChromosomes * sizeof(int *));
	if(classical_pop == 0)
	{
	    printf("couldnot alloc mem \n");
	    exit(1);
	}
    for(i = 0; i < noOfChromosomes; i++) 
	{
	    classical_pop[i] =(int*) malloc(noOfNodes* sizeof(int));
	    if(classical_pop[i] == 0)
	    {
	        printf("couldnot alloc mem to %d\n",i);
	        exit(1);
	    }
	}

    tempChromosome=(int*)malloc(sizeof(int)*noOfNodes);
	if(tempChromosome==NULL)
	{
		printf("\n malloc error -tempChromosome \n");
		exit(1);
	}
	for(i=0;i<noOfChromosomes;++i)
	{
		for(j=0;j<noOfNodes;++j)
		{
			classical_pop[i][j] = 1;
		}
		//printf("\n");
	}
	//printf("\nini working fine\n ");
}

void measure()
{
		int rowIdx,colIdx,idx;
		//int nc=(int)pow(2,k);
		double randomNo,sum;
        
		for(rowIdx=0;rowIdx<noOfChromosomes;rowIdx++)
		{
			for(colIdx=0;colIdx<noOfNodes;colIdx++)	
			{	
				
			    randomNo=random_real();
			    sum = 0.0;
			    //classical_pop[rowIdx][colIdx]=1; 
			    for(idx=nc-1;idx>=0;idx--)
			    {
				   sum+=pow(chromosomes[rowIdx*nc+idx][colIdx],2);
				   if(randomNo<sum)
				   {
					 classical_pop[rowIdx][colIdx]=idx+1;
					 break;
				   }
			    }
		    }
	    }
		
	/*for(rowIdx=0;rowIdx<noOfChromosomes;rowIdx++)
	{
		printf("chromosome %d\n",rowIdx+1);
		for(colIdx=0;colIdx<noOfNodes;colIdx++)
		{
			printf("%d ",classical_pop[rowIdx][colIdx]);
		}
		printf("\n");
	}*/
}

/*void repair()
{
	int i,j,repair_chromosome, repair_node;
    double r;
	repair_chromosome=rand()%noOfChromosomes;
	r=random_real();
	//printf("r is %lf\n",r);
	if(r > alpha)
	{
		repair_node=rand()%noOfNodes;
		r=random_real();
		if(r > beta)
	    {
	       for(i=0;i<noOfNodes;i++)
	       {
		      if(input_graph[repair_node][i] == 1)
		      {
			    classical_pop[repair_chromosome][i] = classical_pop[repair_chromosome][repair_node];
		      }
	       }
	    }
    }
}
*/
void repair()
{
	int i,j,r,c;
    double rn;
	//repair_chromosome=rand()%noOfChromosomes;
	for(r=0;r<noOfChromosomes;r++)
	{
	  rn=random_real();
	  //printf("r is %lf\n",rn);
	  if(rn < alpha)
	  {
	     //repair_node=rand()%noOfNodes;
		 for(c=0;c<noOfNodes;c++)
		 {
		   rn=random_real();
		   if(rn < beta)
	       {
	         for(i=0;i<noOfNodes;i++)
	         {
		       if(input_graph[c][i] != 0)
		       {
			     classical_pop[r][i] = classical_pop[r][c];
		       }
	         }
	       }
	     }
      }
    }
}

double compute_theta(int x, int b, int chromosome)
{
	double f_x,f_b;
	f_x = obj_func(chromosome);
	f_b = obj_func(-1);
	if(x == b)
	{
        if(f_x < f_b)
		   return theta2;
		else
		   return theta1;
	}
	else
	{
		if(x < b)
		{
			if(f_x < f_b)
			   return theta1;
			else
			   return theta2;
		}
		else
		{
			if(f_x < f_b)
			   return -theta1;
			else
			   return -theta2;
		}
	}
}
// k = ((i * noOfChromosomes) + state)* nc + j
// i = mutated chromosome
// j = mutated gene
void update(int chromosome)
{
	int i,k,x_bit,b_bit;
	double t1,t2,rotation_angle,sum;
	for(i=0;i<noOfNodes;i++)
	{
	   x_bit = classical_pop[chromosome][i];
	   b_bit = best_classical[i];
	   t1 = chromosomes[chromosome*nc + x_bit-1][i];
	   t2 = chromosomes[chromosome*nc + b_bit-1][i];
	   
	   rotation_angle = compute_theta(x_bit,b_bit,chromosome)* 3.14;
	    
	   chromosomes[chromosome*nc + x_bit-1][i] = cos(rotation_angle)*t1 - sin(rotation_angle)*t2;
	   chromosomes[chromosome*nc + b_bit-1][i] = sin(rotation_angle)*t1 + cos(rotation_angle)*t2;
	   
	   sum=0;
	   for(k=0;k<nc;k++)
	   {
	   	 sum = sum + pow(chromosomes[chromosome*nc+k][i],2);
	   }
	   if(sum != 1)
	   {
	   	 //printf("%lf\n",sum);
		 sum=sqrt(sum);
	   	 for(k=0;k<nc;k++)
	   	    chromosomes[chromosome*nc+k][i] /= sum;
	   }	
	}
    

}

void mutate(int i)
{
	int j,xOld,xNew,k,t,s;
	double randomNo,temp,oldNM,newNM;
   	
	randomNo=random_real();	
	if(randomNo < mutRate)// mutarte is probability of selection of classical chromosome fr mutation
    {
		for(j=0;j<noOfNodes;++j)
		{
			randomNo=random_real();	
			
			if(randomNo < 1.0/noOfNodes)//jth gene selected fr mutation
			{
				oldNM=obj_func(i);
				for(k=0;k<noOfNodes;++k)
				{
					tempChromosome[k]=classical_pop[i][k];
			    }
				
                classical_pop[i][j]=floor((nc)*randomNo*noOfNodes);
                //classical_pop[i][j]=floor((nc-1)*randomNo);
                classical_pop[i][j]++;
                //printf("%d\n",classical_pop[i][j]);
				//repair part 
				for(k=0;k<noOfNodes;k++)
	       		{
		      	   if(input_graph[j][k] != 0)
			    	  classical_pop[i][k] = classical_pop[i][j];
		      	}
			
				newNM=obj_func(i);
				if(newNM > oldNM)// changes in quantum chromosome
				{
		            xOld=tempChromosome[j];
		            xNew=classical_pop[i][j];
					temp=chromosomes[i*nc+xOld-1][j];
					chromosomes[i*nc+xOld-1][j]=chromosomes[i*nc+xNew-1][j];
					chromosomes[i*nc+xNew-1][j]=temp;
					// reverting repair part*/
					for(k=0;k<noOfNodes;k++)
	       			{
		      			if(input_graph[j][k] != 0)
		      			{
							xOld=tempChromosome[k];
							xNew=classical_pop[i][k];
							temp=chromosomes[i*nc+xOld-1][k];
							chromosomes[i*nc+xOld-1][k]=chromosomes[i*nc+xNew-1][k];
							chromosomes[i*nc+xNew-1][k]=temp;
					     }
		      		}
		      		no_mut++;
		      		if(newNM > fitness_val)
		      		{
		      			fitness_val = newNM;
	  		            for(t=0;t<noOfNodes;t++)
	                       best_classical[t] = classical_pop[i][t];
	                    for(s=0;s<nc;s++)
	                      for(t=0;t<noOfNodes;t++)
	                      {
	    	                best_quantum[s][t] = chromosomes[i*nc + s][t];
	                      }
	                   printf("\n %lf ",fitness_val);   
		      		}
				}
				else
				for(k=0;k<noOfNodes;++k)
				{
					classical_pop[i][k] = tempChromosome[k];
				}
				
			}
		}
		
    }

    /*printf("\n\n in mutate \n");
	for(i=0;i<noOfChromosomes;i++)
	{
		printf("chromosome %d\n",i+1);
		for(j=0;j<noOfNodes;j++)
		{
			printf("%d ",classical_pop[i][j]);
		}
		printf("\n");
	}*/
}

void qiea()
{
	  int i,j,k,fit_chrom=0,t=0;
	  double fit_val;
	  double prev_best;
	  int final;
	  FILE *fp1;
	  fitness_val = -0.5;
	  best_classical =(int*)malloc(noOfNodes * sizeof(int *));
	  //fp1 = fopen("output.txt", "a");
	  best_quantum =(double**)malloc(nc * sizeof(double *));
	  if(best_quantum == 0)
	    {
	    	printf("\n error in best_sol malloc");
	    	exit(1);
	    }
	  for(i = 0; i < nc; i++) 
	  {
	    best_quantum[i] =(double*) malloc(noOfNodes* sizeof(double));
	    if(best_quantum[i] == 0)
	    {
	    	printf("\n error in best_sol malloc");
	    	exit(1);
	    }
	  }
	  initialize();
	  measure();
	  repair();
	  for(i=0;i<noOfChromosomes;i++)
	  {
	  	fit_val = obj_func(i);
	  	//printf("%lf\n ",fit_val);
	  	if(fitness_val < fit_val)
	  	{
	  		fitness_val = fit_val;
	  		fit_chrom = i;
	  	}   
	  }
	     //printf(" nc %d ", nc);  
	  for(j=0;j<noOfNodes;j++)
	    best_classical[j] = classical_pop[fit_chrom][j];
	    
	     //printf(" fit chrom %d ", fit_chrom); 
	  for(i=0;i<nc;i++)
	    for(j=0;j<noOfNodes;j++)
	    { 
	    	best_quantum[i][j] = chromosomes[fit_chrom*nc + i][j];
	    	//printf(" chrom %d ", fit_chrom*nc + i-1); 
	    }
	        
	  while(t<generations)  
	  {
	  	 //printf("\n iteration %d\n",t);
	     //if(t>0)
	     //{
	     prev_best=fitness_val;
		  measure();
          repair();
         //}
		 fit_chrom = -1;  
		 for(i=0;i<noOfChromosomes;i++)
	     {
	  	   fit_val = obj_func(i);
	  	   if(fitness_val < fit_val)
	  	   {
	  		 fitness_val = fit_val;
	  		 fit_chrom = i;
	  	   }   
	     }
	     //printf(" nc %d ", nc);
		 if(fit_chrom != -1)
		 {
		 	//printf("\n initial best sol with ntwk mod Q: %lf\n", obj_func(-1));
		   for(j=0;j<noOfNodes;j++)
	          best_classical[j] = classical_pop[fit_chrom][j];
	        
	       for(i=0;i<nc;i++)
	        for(j=0;j<noOfNodes;j++)
	        {
	    	  best_quantum[i][j] = chromosomes[fit_chrom*nc + i][j]; 
	        }
	     }
		  
		 fit_chrom = -1;
		 //printf("\n call mutate ");
	  	 for(i=0;i<noOfChromosomes;i++)
	  	 {
	  	   mutate(i);
	  	   //update(i);
	  	   /*fit_val = obj_func(i);
	  	   if(fitness_val < fit_val)
	  	   {
	  		  fitness_val = fit_val;
	  		  fit_chrom = i;
	  		  for(j=0;j<noOfNodes;j++)
	            best_classical[j] = classical_pop[fit_chrom][j];
	          for(k=0;k<nc;k++)
	            for(j=0;j<noOfNodes;j++)
	            {
	    	      best_quantum[k][j] = chromosomes[fit_chrom*nc + k][j];
	            }
	  	   }*/
	  	   update(i);
	  	 }
	  	 if(prev_best!=fitness_val)
	  	 	final=t;
	  	 /*if(fit_chrom == -1)
	  	       no_gen++;
	  	 else
	  	 {
	  	   	printf("generation no: %d mod : %lf\n",no_gen,fitness_val);
	  	   	no_gen=0;
	  	 }*/
	  	 t++; 
	  	 	//printf("generation no: %d mod : %lf\n",t,fitness_val);
      }
      fp1 = fopen("output500.txt", "a");
      printf("\nno of iter : %d mod : %lf",no_gen,fitness_val);
      printf("\n best sol with ntwk mod Q: %lf", obj_func(-1));
      printf("\nfinal = %d",final);
      for(j=0;j<noOfNodes;j++)
	    printf(" %d ", best_classical[j]);
	    
	  printf("\n\n***********************************************\n");
	  fclose(fp1);
	   printf("\n best sol with ntwk mod Q: %lf", obj_func(-1));
	
	  //return best_sol;
}
	
int main(int argc, void** argv)
{
	int msec = 0;
    clock_t time_elapsed = clock();
	FILE *fp;
	int i,j;
	char filename[50];
	//char temp[100];
	srand(time(NULL));
	
	//read parameters
	
	
	fp = fopen("parameter2.txt", "r");
    if(fp == NULL)
    {
	   printf("\nparamete File could not be opened in read mode!!!\n");
	   return 1;
    }
    
	fscanf(fp,"%d",&noOfChromosomes);	
	fscanf(fp,"%s",&filename);	
	fscanf(fp,"%lf",&theta1);
	fscanf(fp,"%lf",&theta2);
	fscanf(fp,"%lf",&alpha);
	fscanf(fp,"%lf",&beta);
	fscanf(fp,"%d",&generations);
	fscanf(fp,"%lf",&mutRate);
	fscanf(fp,"%d",&nc);
	
	printf("chromosomes: %d\ntheta1 : %lf\ntheta2 : %lf\nalpha : %lf\nbeta : %lf\nmutRate : %lf\nnc : %d\ngenerarions: %d\n",noOfChromosomes,theta1,theta2,alpha,beta,mutRate,nc,generations);
	
	fclose(fp);
	//read input graph
	fp = fopen(filename, "r");
    if(fp == NULL)
    {
	   printf("\nFile could not be opened in read mode!!!\n");
	   return 1;
    }
    
	j=0;
	char c;
	do
	{
		c=fgetc(fp);
		j++;
	}while(c != '\n');
	
	noOfNodes = j/2;
	fseek(fp,0,SEEK_SET);
	
	input_graph =(int**)malloc(noOfNodes * sizeof(int *));
	for(i = 0; i < noOfNodes; i++) 
	{
	    input_graph[i] =(int*) malloc(noOfNodes* sizeof(int));
	
	}
	
	b_matrix =(double**)malloc(noOfNodes * sizeof(double *));
	for(i = 0; i < noOfNodes; i++) 
	{
	    b_matrix[i] =(double*) malloc(noOfNodes* sizeof(double));
	
	}
	
	indegree =(int*)malloc(noOfNodes * sizeof(int *));
	outdegree =(int*)malloc(noOfNodes * sizeof(int *));
	noOfEdges = 0;
	for(i=0;i<noOfNodes;i++)
	{
	  indegree[i] = 0;
	  outdegree[i] = 0;
	}
	for(i=0;i<noOfNodes;i++)
      for(j=0;j<noOfNodes;j++)
	  {
	     fscanf(fp,"%d",&input_graph[i][j]);
	     if(input_graph[i][j] != 0)
	     { 
	        outdegree[i]+=input_graph[i][j];
	        indegree[j]+=input_graph[i][j];
	        noOfEdges+=input_graph[i][j];
	     }
	     //printf("%d ",input_graph[i][j]);
      }
    
    
    printf("edges : %d\n nodes : %d\n",noOfEdges,noOfNodes);
    //noOfEdges/=2;
	fclose(fp);
	
	for(i=0;i<noOfNodes;i++)
	{
		for(j=0;j<noOfNodes;j++)
		{
			//b_matrix[i][j] = input_graph[i][j] - (degree[i]*degree[j])/(double)(2*noOfEdges);
			b_matrix[i][j] = input_graph[i][j] - (indegree[i]*outdegree[j])/(double)(noOfEdges);
		}
	}
	
	for(i=0;i<1;i++)
	{
	 time_elapsed = clock();
	
	qiea();
	//getch();
	time_elapsed = clock() - time_elapsed;
	msec = time_elapsed * 1000 / CLOCKS_PER_SEC;
	printf("\nTime taken %d seconds %d milliseconds\n",msec/1000, msec%1000);
	
	printf("no of mut : %d\n",no_mut);
	//print sol
	free(chromosomes);
	free(best_quantum);
	free(classical_pop);
	free(best_classical); 
	free(tempChromosome);
    }
    
	free(b_matrix);
	free(indegree);
	free(outdegree);
	free(input_graph); 
}
