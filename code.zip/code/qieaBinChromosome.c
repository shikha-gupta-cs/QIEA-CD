#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
//#define MutRate .15


int **input_graph;
//double theta1 =0.00, theta2 =0.001, theta3 =0.085, theta4 =0.0, theta5 =-0.085, theta6 =-0.0, theta7 =0.00, theta8 =-0.001;
double theta1, theta2, theta3, theta4, theta5, theta6, theta7, theta8, MutRate;
double fmod1, mod_best;
int noOfChromosomes,noOfNodes,noOfEdges,nc,generations,alpha,beta,no_gen=0;
double **chromosomes, **best_quantum, fitness_val, **temp_mod1,*mod;
int **classical_pop, *degree, *best_classical,*tempChromosome;
int next_num=0,cluster_num,mut=0,mut2=0;
double mod2,modval1;
int test1=0,nogen;
double m;
void main_func(double *result);
void qiga_main();
double recursive_QGA(int *CH,int cluster_num,double mod2,int N,int L,double **temp_mod1);
int count(int *CH,int c,int n);
double random_real();
int NoOfNodesF(char * filename);
void ini_mod();
double obj_func(int *ch,double **temp_mod1,int L);
void initialize(int n);
void initialize2(int N);
void ini(int *CH, int n);
void measure(int *CH,int cluster_num,int n,double **temp_mod1,double* mod);
void Qmutate(int cluster_num,int N,int L,double **temp_mod1,double* mod,int* chng);
void update(int cluster_num,int N,double max,double* mod,int* CH);
double qiga(int *CH,int cluster_num,int N,int L,double **temp_mod1);
//int tttttt=5;
double random_real()
{
    return (double)rand() / (double)(RAND_MAX + 1.0)  ;
}

int NoOfNodesF(char * filename)
{
	FILE * fp4 = fopen(filename, "r");
    if(!fp4)
    {
	   printf("\nFile could not be opened in read mode!!!\n");
	   return 1;
    }
    
	int i,j=0;
//	char c;
/*	do
	{
//		c=fgetc(fp);
		printf("\nC is: %c",c);
		j++;
	}while(c != '\n');
*/
	char c;
	do
	{
		c=fgetc(fp4);
		//printf("\nC is: %c",c);
	    if(c==' ')
	    {
		
	       j++;
	    }
	}while(c != '\n');
	//printf("j= %d",j);
	noOfNodes = j+1;

	printf("\nNo of nodes: %d",noOfNodes);
	fseek(fp4,0,SEEK_SET);
	

	
	degree =(int*)malloc(noOfNodes * sizeof(int));
	input_graph =(int**)malloc(noOfNodes * sizeof(int *));
	for(i = 0; i < noOfNodes; i++) 
	{
	    input_graph[i] =(int*) malloc(noOfNodes* sizeof(int));
	
	}
	
	
	
	noOfEdges = 0;
	//printf("\n");
	for(i=0;i<noOfNodes;i++)
	{
	  degree[i] = 0;
	  //printf("\n");
      for(j=0;j<noOfNodes;j++)
	  {
	     fscanf(fp4,"%d",&input_graph[i][j]);
	     if(input_graph[i][j] != 0)
	     { 
	        degree[i]=degree[i]+input_graph[i][j];
	        noOfEdges+=input_graph[i][j];
	     }
	   //  input_graph2[i][j]=input_graph[j][i];
	   	     //printf("%d ",input_graph[i][j]);
      }
    }
    fseek(fp4,0,SEEK_SET);
 /*   for(i=0;i<noOfNodes;i++)
	{
	  degree2[i] = 0;
	 // printf("\n");
      for(j=0;j<noOfNodes;j++)
	  {
	     fscanf(fp4,"%d",&input_graph[i][j]);
	     if(input_graph2[i][j] != 0)
	     { 
	        degree2[i]+=input_graph2[i][j];
	        //noOfEdges++;
	     }
	     //input_graph2[i][j]=input_graph[j][i];
	   	     //printf("%d ",input_graph[i][j]);
      }
    }*/
	fclose(fp4);    
    noOfEdges/=2;
    printf("\nNo of edges : %d",noOfEdges);
	return noOfNodes;
}

void ini_mod()
{
	int i,j,rowIdx,colIdx;
	temp_mod1 =(double**)malloc(noOfNodes * sizeof(double *));
	if(temp_mod1 == 0)
	{
	    printf("couldnot alloc mem \n");
	    exit(1);
	}
    for(i = 0; i < noOfNodes; i++) 
	{
	    temp_mod1[i] =(double*) malloc(noOfNodes* sizeof(double));
	    if(temp_mod1[i] == 0)
	    {
	        printf("couldnot alloc mem to %d\n",i);
	        exit(1);
	    }
	}
	double ntwk_mod = 0;
	for(i=0;i<noOfNodes;i++)
	{
      for(j=0;j<noOfNodes;j++)
	  {
	  	ntwk_mod=0.0;
	  	if(input_graph[i][j]!=0)
	  	{
	  		//printf("\nInputgraph: %d",input_graph[i][j]);
	  		ntwk_mod = input_graph[i][j] - (degree[i]*degree[j])/(double)(2*noOfEdges);	
	  	}
	  	else
	  	{
	  		ntwk_mod = input_graph[i][j] - (degree[i]*degree[j])/(double)(2*noOfEdges);	  
		}
		temp_mod1[i][j]=ntwk_mod/((double)(2*noOfEdges));
	  }
	}	
/*	for(rowIdx=0;rowIdx<noOfNodes;rowIdx++)
	{
		printf("\n");
		for(colIdx=0;colIdx<noOfNodes;colIdx++)
		{
			printf("%f ",temp_mod1[rowIdx][colIdx]);
		}
	}
	printf("\nini_mod working fine");*/
}
double obj_func(int *ch,double **temp_mod1,int L)
{
	//printf("\n in obj with %d\n",n);
	int i,j;
	double ntwk_mod = 0;
	
	for(i=0;i<L;i++)
      for(j=0;j<L;j++)
	  {
	  	if(ch[i] == ch[j])
	  	
	  		ntwk_mod = ntwk_mod + temp_mod1[i][j];
	  	//else
		  	//ntwk_mod = ntwk_mod + temp_mod1[i][j]*0;
	  }	  
	return ntwk_mod;//(double)(2*noOfEdges);
}

void initialize(int n)
{
	int i,j,rows,columns;
	rows=nc*noOfChromosomes;
	columns=n;
	//printf("\n   rows %d  col %d \n",rows,columns);
	//Initialisation of chromosome array
	chromosomes =(double**)malloc(rows * sizeof(double *));
	for(i = 0; i < rows; i++) 
	{
	    chromosomes[i] =(double*) malloc(columns* sizeof(double));
	
	}
	double ncSqrt=sqrt(2);
	for(i=0;i<rows;++i)
	{
		for(j=0;j<columns;++j)
		{
			chromosomes[i][j]=1/ncSqrt;
		}
	}
}	//classical_pop is used for classical chromosome , each gene can take a numeric value

void initialize2(int N)
{
	int i,j,rows,columns;
	rows=nc*noOfChromosomes;
	columns=N;
	printf("\n Initialisation of chromosome array \n");
	//Initialisation of chromosome array
	/*chromosomes =(double**)malloc(rows * sizeof(double *));
	for(i = 0; i < rows; i++) 
	{
	    chromosomes[i] =(double*) malloc(columns* sizeof(double));
	
	}*/
	//double ncSqrt=sqrt(nc);
	for(i=0;i<rows;i=i+2)
	{
		for(j=0;j<columns;++j)
		{
			chromosomes[i][j]=best_quantum[0][j];
			chromosomes[i+1][j]=best_quantum[1][j];
		}
	}
	
	
		//classical_pop is used for classical chromosome , each gene can take a numeric value
	/*classical_pop =(int**)malloc(noOfChromosomes * sizeof(int *));
	if(classical_pop == 0)
	{
	    printf("couldnot alloc mem \n");
	    exit(1);
	}
    for(i = 0; i < noOfChromosomes; i++) 
	{
	    classical_pop[i] =(int*) malloc(noOfNodes* sizeof(int));
	    if(classical_pop[i] == 0)
	    {
	        printf("couldnot alloc mem to %d\n",i);
	        exit(1);
	    }
	}*/
	/*tempChromosome=(int*)malloc(sizeof(int)*noOfNodes);
	if(tempChromosome==NULL)
	{
		printf("\n malloc error -tempChromosome \n");
		exit(1);
	}

	printf("\nUpdated Chromosomes Array: \n");
	for(i=0;i<rows;++i)
	{
		printf("\n");
		for(j=0;j<columns;++j)
		{
			printf("%lf ",chromosomes[i][j]);
		}
		printf("\n");
		break;
	}
	printf("\nini2 working fine\n ");*/
	}
	
void ini(int *CH, int n)
{
	int i,j;
	classical_pop =(int**)malloc(noOfChromosomes * sizeof(int *));
	if(classical_pop == 0)
	{
	    printf("couldnot alloc mem \n");
	    exit(1);
	}
    for(i = 0; i < noOfChromosomes; i++) 
	{
	    classical_pop[i] =(int*) malloc(n* sizeof(int));
	    if(classical_pop[i] == 0)
	    {
	        printf("couldnot alloc mem to %d\n",i);
	        exit(1);
	    }
	}
	for(i=0;i<noOfChromosomes;++i)
	{
		for(j=0;j<n;++j)
		{
			classical_pop[i][j]=CH[j];
		}
	}
	
	
/*	printf("\nChromosomes Array: \n");
	for(i=0;i<rows;++i)
	{
		printf("\n");
		for(j=0;j<columns;++j)
		{
			printf("%lf ",chromosomes[i][j]);
		}
		printf("\n");
	}
	printf("\nini working fine\n ");*/
}
/*void ini2(int*CH,int n)
{

   int i,j;
	for(i=0;i<noOfChromosomes;++i)
	{
		for(j=0;j<n;++j)
		{
			classical_pop[i][j]=CH[j];
		}
	}*/
	
	
/*	printf("\nChromosomes Array: \n");
	for(i=0;i<rows;++i)
	{
		printf("\n");
		for(j=0;j<columns;++j)
		{
			printf("%lf ",chromosomes[i][j]);
		}
		printf("\n");
	}
	printf("\nini working fine\n ");*/
//}

void measure(int *CH,int cluster_num,int n,double **temp_mod1,double* mod)
{
	int rowIdx,colIdx,idx,i;
	double m;
	int max=-5;
		//int nc=(int)pow(2,k);
	
		int *temp =(int*)malloc(n * sizeof(int));
		int *temp1 =(int*)malloc(n * sizeof(int));
		double randomNo,sum;
      //  ini(CH,n);
       // printf("after ini in measure");
        /*for(rowIdx=0;rowIdx<noOfChromosomes;rowIdx++)
	{
		printf("chromosome %d\n",rowIdx+1);
		for(colIdx=0;colIdx<noOfNodes;colIdx++)
		{
			printf("%d ",classical_pop[rowIdx][colIdx]);
		}
		printf("\n");
	}*/
        
		for(rowIdx=0;rowIdx<noOfChromosomes;rowIdx++)
		{
			max=-5;
			//printf("1st for loop");
			for(colIdx=0;colIdx<n;colIdx++)
			{
				
			if((classical_pop[rowIdx][colIdx]==cluster_num)||(classical_pop[rowIdx][colIdx]==next_num))
			    {
			
				sum=0.0;
			    randomNo=random_real();
				sum=pow(chromosomes[rowIdx*nc][colIdx],2);
				if(randomNo<sum)
				{
				  // if(classical_pop[rowIdx][colIdx]==0)
						 classical_pop[rowIdx][colIdx]=next_num;
		//				 printf("initializing classical");
				}
				else
					classical_pop[rowIdx][colIdx]=cluster_num;
				}
				
			//	printf("aftertemp");
			 }
		}
		/*	 for(i=0;i<n;i++)
			 {
			 	temp1[i]=classical_pop[rowIdx][i];
			 	//printf("\n temp[i]= %d",temp[i]);
			 }
			 
			 //printf("before calculating m");
		     m=obj_func(temp1,temp_mod1,n);
		//printf("after calculating m");
		if(m>max)
		{
			max=m;
			for(i=0;i<n;i++)
				temp[i]=classical_pop[rowIdx][i];
		}
		mod[rowIdx]=max;
		for(i=0;i<n;i++)
				classical_pop[rowIdx][i]=temp[i];
	    }*/		
       free(temp);
       free(temp1);
}


/*void measure(int *CH,int cluster_num,int n,double **temp_mod1)
{
	int rowIdx,colIdx,idx,k;
	double m,max=-5;
	
		//int nc=(int)pow(2,k);
		mod =(double*)malloc(noOfChromosomes * sizeof(double));
		int *temp =(int*)malloc(n * sizeof(int));
		int *temp1 =(int*)malloc(n * sizeof(int));
		double randomNo,sum;
        ini(CH,n);    
       // printf("after ini in measure");
        /*for(rowIdx=0;rowIdx<noOfChromosomes;rowIdx++)
	{
		printf("chromosome %d\n",rowIdx+1);
		for(colIdx=0;colIdx<noOfNodes;colIdx++)
		{
			printf("%d ",classical_pop[rowIdx][colIdx]);
		}
		printf("\n");
	}*/
        
/*		for(rowIdx=0;rowIdx<noOfChromosomes;rowIdx++)
		{
		
			//printf("1st for loop");
		//	ini(CH,n);
			//max=-5;
			for(k=0;k<2;k++)
			{
				
			for(colIdx=0;colIdx<n;colIdx++)
			{
				
				
			if((classical_pop[rowIdx][colIdx]==cluster_num)||(classical_pop[rowIdx][colIdx]==next_num))
			    {
			
				sum=0.0;
			    randomNo=(double)rand()/(double)(RAND_MAX + 1.0);
	//		    printf("\n randomno==%lf\n",randomNo);
				sum=pow(chromosomes[rowIdx*nc][colIdx],2);
				if(randomNo<sum)
				{
				  // if(classical_pop[rowIdx][colIdx]==0)
						 classical_pop[rowIdx][colIdx]=next_num;
		//				 printf("initializing classical");
				}
				else
					classical_pop[rowIdx][colIdx]=cluster_num;
				}
				
			//	printf("aftertemp");
			 }
			 for(int i=0;i<n;i++)
			 {
			 	temp1[i]=classical_pop[rowIdx][i];
			 	//printf("\n temp[i]= %d",temp[i]);
			 }
			 
			 //printf("before calculating m");
		     m=obj_func(temp1,temp_mod1,n);
		//printf("after calculating m");
		if(m>max)
		{
			max=m;
			for(int i=0;i<n;i++)
				temp[i]=classical_pop[rowIdx][i];
		}
		}
		mod[rowIdx]=max;
		for(int i=0;i<n;i++)
				classical_pop[rowIdx][i]=temp[i];
	    }		
	/*for(rowIdx=0;rowIdx<noOfChromosomes;rowIdx++)
	{
		printf("chromosome %d\n",rowIdx+1);
		for(colIdx=0;colIdx<noOfNodes;colIdx++)
		{
			printf("%d ",classical_pop[rowIdx][colIdx]);
		}
		printf("\n");
	}
	printf("\nmeasure working fine");*/
//}

void Qmutate(int cluster_num,int N,int L,double **temp_mod1,double* mod,int* chng)
{
	int i,j,xOld,xNew,k;
	double randomNo,temp,oldNM,newNM,rand;
	

	for(i=0;i<noOfChromosomes;i++)
	{
	   
	    rand = random_real();
 		if(rand < MutRate)
 		{
		   
	 		for(j=0;j<N;++j)
 			{
 		
 		
 		
 	
				randomNo=random_real();	
				if((randomNo < 1.0/L)&&((classical_pop[i][j]==cluster_num)||(classical_pop[i][j]==next_num)))//jth gene selected fr mutation
				{
		
		    if(classical_pop[i][j]==cluster_num)
		    {
		    	classical_pop[i][j]=next_num;
		    	chng[i]=1;
		    }
		    else if(classical_pop[i][j]==next_num)
		         classical_pop[i][j]=cluster_num;
		         chng[i]=1;
		     
		    /*for(k=0;k<N;k++)
		    {
			tempChromosome2[k]=classical_pop[i][k];
			}
			newNM=obj_func(tempChromosome2,temp_mod1,L);
			//printf("\n ***%lf***", newNM); 
			if(newNM > mod[i])// changes in quantum chromosome
			{
			    mut++;
				//mod[i]=newNM;
				temp=chromosomes[i*nc][j];	//value of a
				chromosomes[i*nc][j]=chromosomes[i*nc+1][j];	//value of a changed to b
				chromosomes[i*nc+1][j]=temp;
			}
			else
			for(k=0;k<N;++k)
			{
				classical_pop[i][k] = tempChromosome[k];
			}*/
		}
	}
		}
	}
	//free(tempChromosome);
	//free(tempChromosome2);
}


/*void Qmutate(int cluster_num,int N,int L,double **temp_mod1)
{
	int i,j,xOld,xNew,k;
	double randomNo,temp,oldNM,newNM;
	int *tempChromosome=(int*)malloc(sizeof(int)*N);
	int *tempChromosome2=(int*)malloc(sizeof(int)*N);
	if(tempChromosome==NULL)
	{
		printf("\n malloc error -tempChromosome \n");
		exit(1);
	}
	for(i=0;i<noOfChromosomes;i++)
	{
		
	for(j=0;j<N;++j)
	{
		randomNo=random_real();	
		if((randomNo < 1.0/L)&&((classical_pop[i][j]==cluster_num)||(classical_pop[i][j]==next_num)))//jth gene selected fr mutation
		{
			//oldNM=obj_func(n);
			for(k=0;k<N;++k)
			{
				tempChromosome[k]=classical_pop[i][j];
		    }
		    //oldNM=obj_func(tempChromosome,temp_mod1);
		    if(classical_pop[i][j]==cluster_num)
		    	classical_pop[i][j]=next_num;
		    else
		    	classical_pop[i][j]=cluster_num;
			tempChromosome2[j]=classical_pop[i][j];
			newNM=obj_func(tempChromosome2,temp_mod1,L);
			if(newNM > mod[i])// changes in quantum chromosome
			{
				mod[i]=newNM;
				temp=chromosomes[i*nc][j];	//value of a
				chromosomes[i*nc][j]=chromosomes[i*nc+1][j];	//value of a changed to b
				chromosomes[i*nc+1][j]=temp;
			}
			else
			for(k=0;k<N;++k)
			{
				classical_pop[i][k] = tempChromosome[k];
			}
		}
		}
	}
}*/

//	printf("\nmutate working fine");
/*
double compute_theta(int x, int b, int chromosome,int i,int cluster_num,int N,double **temp_mod1)
{
	int *temp_ch=(int*)malloc(sizeof(int)*N);
	double f_x,f_b,a_val,b_val;
	double pi=3.14;
	a_val=chromosomes[chromosome*nc][i];
	b_val=chromosomes[chromosome*nc+1][i];
	for(int t=0;t<N;t++)
		temp_ch[t]=classical_pop[chromosome][t];
	f_x = obj_func(temp_ch,temp_mod1);
	f_b = fitness_val;
    if((b==cluster_num)&&(f_x<f_b))
		return 0;
	if(x == b)
		   return 0;
	else
	{
		if(x < b)
		{
			if(f_x < f_b)
			{
				if((a_val>0)&&(b_val>0))
					return (-0.05*pi);
				else
					return (0.05*pi);
			}
			else
			   return 0;
		}
		else
		{
			if(f_x < f_b)
			   return 0;
			else
			{
				if((a_val>0)&&(b_val>0))
					return (0.05*pi);
				else
					return (-0.05*pi);
			}
		}
	}
}
*/
/*void update(int cluster_num,int N,double max)
{
	double pi=3.14;
	int j,i,x_bit,b_bit,sign,flag;
	double t1,t2,rotation_angle,a_val,b_val,theta=0;
	for(j=0;j<noOfChromosomes;j++)
	{
		if(mod[j]>=max)
			sign=1;
		else
			sign=0;
	for(i=0;i<N;i++)
	{
		if((classical_pop[j][i]==cluster_num)||(classical_pop[j][i]==next_num))
		{
			if(sign==0)
			{
				a_val=chromosomes[j*nc][i];
				b_val=chromosomes[j*nc+1][i];
				if((a_val*b_val)>0)	
					flag=1;
				else
					flag=0;
			//	if(classical_pop[j][i]==cluster_num && best_classical[i]==next_num)
			//	{	
				if(classical_pop[j][i]==cluster_num && best_classical[i]==next_num)
				{
					if(flag==1)
						theta = -theta1*pi;
					else
						theta = theta1*pi;
					chromosomes[j*nc][i] = cos(theta)*a_val - sin(theta)*b_val;
	   				chromosomes[j*nc+1][i] = sin(theta)*a_val + cos(theta)*b_val;	
			    }
				else
				{
					if(classical_pop[j][i]==next_num && best_classical[i]==cluster_num)
					{
					if(flag==1)
						theta = theta1*pi;
					else
						theta = -theta1*pi;
					chromosomes[j*nc][i] = cos(theta)*a_val - sin(theta)*b_val;
	   				chromosomes[j*nc+1][i] = sin(theta)*a_val + cos(theta)*b_val;	
					}
				//	else
				//{
				//	theta=0;
				//	chromosomes[j*nc][i] = cos(theta)*a_val - sin(theta)*b_val;
	   			//	chromosomes[j*nc+1][i] = sin(theta)*a_val + cos(theta)*b_val;
				//}	
				}
				
			}
	   	}
	}
}
}

*/

void update(int cluster_num,int N,double max,double*mod,int* CH)
{

    int true_false=1,i,j;
 double a_val,b_val,theta;
//#define PI 3.141592653589793
    double pi=(22.0/7.0);
    for(i=0;i<noOfChromosomes;i++)
    {
    
    	if (mod[i] < max) 
		        true_false=1;
    		else true_false=0;
        for(j=0;j<N;j++)
        {
        
    	if (classical_pop[i][j]==cluster_num){
//		printf("pt==cluster ");
            if (CH[j]==cluster_num){
//		printf("b==cluster  ");
                if (true_false==1)
                   theta = theta1 * pi ;
                else theta = theta2 *pi ;
//		printf("pi=%f,theta=%f\n", pi,theta);
            }
            else if (CH[j]==next_num){
                if (true_false==1)
                   theta = theta3 *pi ;
                else theta = theta4 *pi ;
            }
        }
        else if (classical_pop[i][j]==next_num){
                if (CH[j]==cluster_num){
                    if (true_false==1)
                        theta = theta5 *pi ;
                    else theta = theta6 *pi ;
                }
                else if (CH[j]==next_num){
                    if (true_false==1)
                        theta = theta7 *pi ;
                    else theta = theta8 *pi ;
        }
    }
    
        	a_val=chromosomes[i*nc][j];
				b_val=chromosomes[i*nc+1][j];    
    	chromosomes[i*nc][j] = cos(theta)*a_val - sin(theta)*b_val;
	   	chromosomes[i*nc+1][j] = sin(theta)*a_val + cos(theta)*b_val;
    
}

}
 // __syncthreads();
}















/*void update(int cluster_num,int N,double max,double *mod,int* CH)
{
	double pi=3.14;
	int j,i,x_bit,b_bit,sign,flag;
	double t1,t2,rotation_angle,a_val,b_val,theta=0;
	for(j=0;j<noOfChromosomes;j++)
	{
		if(mod[j]>=max)
			sign=1;
		else
			sign=0;
	for(i=0;i<N;i++)
	{
		if((classical_pop[j][i]==cluster_num)||(classical_pop[j][i]==next_num))
		{
			if(sign==0)
			{
				a_val=chromosomes[j*nc][i];
				b_val=chromosomes[j*nc+1][i];
				if((a_val*b_val)>0)	
					flag=1;
				else
					flag=0;
				if(classical_pop[j][i]==cluster_num && CH[i]==next_num)
				{
					if(flag==1)
						theta = -theta11*pi;
					else
						theta = theta11*pi;
					chromosomes[j*nc][i] = cos(theta)*a_val - sin(theta)*b_val;
	   				chromosomes[j*nc+1][i] = sin(theta)*a_val + cos(theta)*b_val;	
				}
				else
				{
					if(classical_pop[j][i]==next_num && CH[i]==cluster_num)
					{
					if(flag==1)
						theta = theta11*pi;
					else
						theta = -theta11*pi;
					chromosomes[j*nc][i] = cos(theta)*a_val - sin(theta)*b_val;
	   				chromosomes[j*nc+1][i] = sin(theta)*a_val + cos(theta)*b_val;	
					}	
				}
			}
	   	}
	}
}
}
*/
double qiga(int *CH,int cluster_num,int N,int L,double **temp_mod1)
{
    printf("\n inqiga\n");
    int i;
	next_num++;
	FILE *fp2;
	ini(CH,L);
	int** classical_pop_temp =(int**)malloc(noOfChromosomes * sizeof(int *));
	if(classical_pop_temp == 0)
	{
	    printf("couldnot alloc mem \n");
	    exit(1);
	}
    for(i = 0; i < noOfChromosomes; i++) 
	{
	    classical_pop_temp[i] =(int*) malloc(N* sizeof(int));
	    if(classical_pop_temp[i] == 0)
	    {
	        printf("couldnot alloc mem to %d\n",i);
	        exit(1);
	    }
	}
	
	int *chng =(int*)malloc(noOfChromosomes * sizeof(int));
	double*	mod =(double*)malloc(noOfChromosomes * sizeof(double));
	best_classical =(int*)malloc(N * sizeof(int ));
    //int *temp_ch =(int*)malloc(N * sizeof(int ));
	int *temp_ch =(int*)malloc(N * sizeof(int ));
	double mod1=0,prev_best=0.0,prev_max=0.0,fit_val=0,newM=0.0,temp;
	int j,k,final=0,num_gen=0,same_val=0,fit_chrom=0;
	//ini(CH,N);
	fitness_val= -0.5;
	best_quantum =(double**)malloc(nc * sizeof(double *));
	if(best_quantum == 0)
	{
		printf("\n error in best_sol malloc");
	   	exit(1);
	}
	for(i = 0; i < nc; i++) 
	{
	   best_quantum[i] =(double*) malloc(N* sizeof(double));
	   if(best_quantum[i] == 0)
	   {
	   	printf("\n error in best_sol malloc");
	   	exit(1);
	   }
	}
		double** temp_quantum =(double**)malloc(nc * sizeof(double *));
	if(temp_quantum == 0)
	{
		printf("\n error in best_sol malloc");
	   	exit(1);
	}
	for(i = 0; i < nc; i++) 
	{
	   temp_quantum[i] =(double*) malloc(N* sizeof(double));
	   if(temp_quantum[i] == 0)
	   {
	   	printf("\n error in best_sol malloc");
	   	exit(1);
	   }
	}

	initialize(N);
	measure(CH,cluster_num,N,temp_mod1,mod);
	for(i=0;i<noOfChromosomes;i++)
	{
	for(j=0;j<N;j++)
		
			temp_ch[j]=classical_pop[i][j];
	  	  mod[i] = obj_func(temp_ch,temp_mod1,L);
	  	//printf("%lf\n ",fit_val);
	  	if(fitness_val < mod[i])
	  	{
	  		fitness_val = mod[i];
	  		fit_chrom = i;
	  	}
	   
   }
	for(i=0;i<N;i++)
	    CH[i] = classical_pop[fit_chrom][i];
	mod1=fitness_val;
	for(i=0;i<nc;i++)
	    for(j=0;j<N;j++)
	    { 
	    	best_quantum[i][j] = chromosomes[fit_chrom*nc + i][j];
	    	temp_quantum[i][j] = chromosomes[fit_chrom*nc + i][j];
	    	
	    	//printf(" chrom %d ", fit_chrom*nc + i-1); 
	    }
	 for(j=0;j<N;j++)
	   best_classical[j]=CH[j];
	    fp2 = fopen("outfile.txt","w");
	while(num_gen<generations)// && same_val<alpha)
	{
		//printf("Iteration");
		prev_best=mod1;
		prev_max=fitness_val;
	    //free(classical_pop);
		  measure(CH,cluster_num,N,temp_mod1,mod);
		
	    fit_chrom = -1; 
		/*for(i=0;i<noOfChromosomes;i++)
		{
		//for(j=0;j<N;j++)
		//{
		//	temp_ch[j]=classical_pop[i][j];
	  	fit_val = mod[i];//obj_func(temp_ch,temp_mod1,L);
	  	//printf("%lf\n ",fit_val);
	  	if(fitness_val < fit_val)
	  	{
	  		fitness_val = fit_val;
	  		fit_chrom = i;
	  	}
	} */
		 for(i=0;i<noOfChromosomes;i++)
	     {
	     	for(j=0;j<N;j++)
				temp_ch[j]=classical_pop[i][j];
	  	     mod[i] = obj_func(temp_ch,temp_mod1,L);
	  	   if(fitness_val < mod[i])
	  	   {
	  		 fitness_val = mod[i];
	  		 fit_chrom = i;
	  	   }   
	     }
	     //printf(" nc %d ", nc);
 	 if(fit_chrom != -1)
		 {
		   for(j=0;j<N;j++)
	          CH[j] = classical_pop[fit_chrom][j];
	       for(i=0;i<nc;i++)
	    	 for(j=0;j<N;j++)
	        	{
	    	 		temp_quantum[i][j] = chromosomes[fit_chrom*nc + i][j]; 
	        	}	
	    }
		//mod1=fitness_val;
	    fit_chrom=-1;
	    for(i=0;i<noOfChromosomes;++i)
	    {
		for(j=0;j<N;++j)
		{
			classical_pop_temp[i][j]=classical_pop[i][j];
		}
	    }
		for(i=0;i<noOfChromosomes;i++)
		  chng[i]=0;
		Qmutate(cluster_num,N,L,temp_mod1,mod,chng);
		
		for(i=0;i<noOfChromosomes;i++)
		{
		   if(chng[i]==1)
		   {
		      	for(k=0;k<N;k++)
				 temp_ch[k]=classical_pop[i][k];
	  	       newM = obj_func(temp_ch,temp_mod1,L);
	  	       if(newM>mod[i])
	  	       {
	  	          mut++;
	  	          mod[i]=newM;
	  	          for(j=0;j<N;j++)
	  	          {
	  	           temp=chromosomes[i*nc][j];	//value of a
				   chromosomes[i*nc][j]=chromosomes[i*nc+1][j];	//value of a changed to b
				   chromosomes[i*nc+1][j]=temp;
				  }
			    }
			    else
			    {
                    for(j=0;j<N;j++)
                     classical_pop[i][j]=classical_pop_temp[i][j];
                 }
            }
           }
		      
		
		
		/*for(i=0;i<noOfChromosomes;i++)
	     {
	     	for(j=0;j<N;j++)
				temp_ch[j]=classical_pop[i][j];
	  	     mod[i] = obj_func(temp_ch,temp_mod1,L);
	  	   if(fitness_val < mod[i])
	  	   {
	  		 fitness_val = mod[i];
	  		 fit_chrom = i;
	  	   }   
	     }*/
	     //printf(" nc %d ", nc);
 	 if(fit_chrom != -1)
		 {
		   for(j=0;j<N;j++)
	          CH[j] = classical_pop[fit_chrom][j];
	       for(i=0;i<nc;i++)
	    	 for(j=0;j<N;j++)
	        	{
	    	 		temp_quantum[i][j] = chromosomes[fit_chrom*nc + i][j]; 
	        	}	
	    }
		
		update(cluster_num,N,mod1,mod,CH);
		if(mod1<=fitness_val)
		{
		 for(i=0;i<N;i++)
		  best_classical[i]=CH[i];
		 mod1=fitness_val;
		 for(i=0;i<nc;i++)
	    	 for(j=0;j<N;j++)
	        	{
	    	 		best_quantum[i][j] = temp_quantum[i][j]; 
	        	}	
		 
		}

	
		if(prev_best<mod1)
		{
		
			final=num_gen;
				
		//	num_gen++;
       }
    
  


		if(fitness_val==prev_max)
			same_val=same_val+1;
		else
			same_val=0;
		
		/*
		if(same_val==alpha && num_gen<beta)
		{
			test1++;
			theta1=THETA;
			initialize(N);
			for(i=0;i<2;i++)
	    	 for(j=0;j<N;j++)
	        	{
	    	 		chromosomes[i][j] = best_quantum[i][j]; 
	        	}	
			same_val=0;
		}*/
	//free(mod);
	//printf("\n\nno_gen : %d,    mod: %f    fit_val: %f\t",num_gen,mod1,fit_val);
	//if(fit_chrom==-1)
	  num_gen=num_gen + 1;
//	num_gen=num_gen + 1;
}
	printf("no of iter : %d mod : %lf\n",num_gen,mod1);
	 printf("bestclassical");
      for(j=0;j<N;j++)
	    printf(" %d ", best_classical[j]);
	   
	    fprintf(fp2,"\n\nno_gen per Qiga===%d\t",num_gen);
	    printf("***final = %d ****",final);
	    nogen=nogen+num_gen;
		fclose(fp2);
	   free(temp_ch);
	    free(classical_pop);
        free(chromosomes);
        free(best_quantum);
        free(temp_quantum);
        free(mod);
        return mod1;
}


/*void qiga(int *CH,int cluster_num,int N,int L,double **temp_mod1)
{
	//printf("\n in qiga");
	int i,j,k,fit_chrom=0,t=0,no_gen=0;
	double fit_val;
	double mod1=0;
	fitness_val = -0.5;
	next_num++;
	int *temp_ch =(int*)malloc(N * sizeof(int ));
	best_classical =(int*)malloc(N * sizeof(int ));
	best_quantum =(double**)malloc(nc * sizeof(double *));
	//next_num++;
	if(best_quantum == 0)
	{
		printf("\n error in best_sol malloc");
	   	exit(1);
	}
	for(i = 0; i < nc; i++) 
	{
	   best_quantum[i] =(double*) malloc(N* sizeof(double));
	   if(best_quantum[i] == 0)
	   {
	   	printf("\n error in best_sol malloc");
	   	exit(1);
	   }
	}
	if(L==noOfNodes)
		initialize(L);
	//printf("\n after initialize");
	measure(CH,cluster_num,N,temp_mod1);
	//printf("\nafter measure");
	for(i=0;i<noOfChromosomes;i++)
	{
		for(j=0;j<N;j++)
			temp_ch[j]=classical_pop[i][j];
	  	fit_val = obj_func(temp_ch,temp_mod1,L);
	  	//printf("%lf\n ",fit_val);
	  	if(fitness_val < fit_val)
	  	{
	  		fitness_val = fit_val;
	  		fit_chrom = i;
	  	}   
	}
//	printf("%f",fitness_val);
	for(j=0;j<N;j++)
	    best_classical[j] = classical_pop[fit_chrom][j];
	mod1=fitness_val;
	//printf(" fit chrom %d ", fit_chrom); 
	for(i=0;i<nc;i++)
	    for(j=0;j<N;j++)
	    { 
	    	best_quantum[i][j] = chromosomes[fit_chrom*nc + i][j];
	    	//printf(" chrom %d ", fit_chrom*nc + i-1); 
	    }
	//printf("\n t is: %d",t);
	//printf("\n generations is: %d",generations);
	while(no_gen<generations)  
	  {
	  	 //printf("\n iteration %d\n",t);
	     if(t>0)
		  measure(CH,cluster_num,N,temp_mod1);

		 fit_chrom = -1;  
		 for(i=0;i<noOfChromosomes;i++)
	     {
	     	for(j=0;j<N;j++)
				temp_ch[j]=classical_pop[i][j];
	  	   fit_val = obj_func(temp_ch,temp_mod1,L);
	  	   if(fitness_val < fit_val)
	  	   {
	  		 fitness_val = fit_val;
	  		 fit_chrom = i;
	  	   }   
	     }
	     //printf(" nc %d ", nc);
		 if(fit_chrom != -1)
		 {
		   for(j=0;j<N;j++)
	          best_classical[j] = classical_pop[fit_chrom][j];
	       for(i=0;i<nc;i++)
	    	 for(j=0;j<N;j++)
	        	{
	    	 		best_quantum[i][j] = chromosomes[fit_chrom*nc + i][j]; 
	        	}	
		}
		 fit_chrom = -1;
		 //printf("\n call Qmutate ");
	  	 //for(i=0;i<noOfChromosomes;i++)
	  	 //{
	  	 mod1=fitness_val;
	  	   Qmutate(cluster_num,N,L,temp_mod1);
	  	   update(cluster_num,N,mod1);
	  	   for(i=0;i<noOfChromosomes;i++)
	  	   {
	  	   	for(j=0;j<N;j++)
				temp_ch[j]=classical_pop[i][j];
	  	   fit_val = obj_func(temp_ch,temp_mod1,L);
	  	   if(fitness_val < fit_val)
	  	   {
	  		  fitness_val = fit_val;
	  		  fit_chrom = i;
	  		  for(j=0;j<N;j++)
	            best_classical[j] = classical_pop[fit_chrom][j];
	          for(k=0;k<nc;k++)
	            for(j=0;j<N;j++)
	            {
	    	      best_quantum[k][j] = chromosomes[fit_chrom*nc + k][j];
	            }
	  	   }
		//	if(i==1)break;
	  	 }
	  	 if(fit_chrom == -1)
	  	       no_gen++;
	  	 else
	  	 {
	  	   	printf("no of iter : %d mod : %lf\n",no_gen,fitness_val);
	  	   	no_gen=0;
	  	 }
	  	 t++; 
      }
	 printf("no of iter : %d mod : %lf\n",no_gen,fitness_val);
      //printf("\n best sol with ntwk mod Q: %lf\n", fitness_val);
      //printf("bestclassical");
      for(j=0;j<N;j++)
	    printf(" %d ", best_classical[j]); 
	//printf("clusternum = %d",cluster_num);
	//printf("nextnum = %d",next_num);
	//	printf("N = %d",N);
	//	printf("L = %d",L);
	
	/*    printf("\nBest quantum solution");
	  for(i=0;i<nc;i++)
	  {
	  	printf("\n\n");
      	for(j=0;j<noOfNodes;j++)
	    	printf(" %f ", best_quantum[i][j]); 
	  }	
	  printf("\nfitness val: %f",fitness_val);*/
//	  free(chromosomes);
//	  free(classical_pop);
//}

int count(int *CH,int c,int n)
{
	int ctr=0,i;
	for(i=0;i<n;i++)
	{
		printf("%d ",CH[i]);
		if(CH[i]==c)
			ctr++;
		else
			continue;
	}
	return ctr;
}
/*
double recursive_QGA(int *CH,int cluster_num,double mod2,int N,int L,double **temp_mod1)
{
	int i,j;
	printf("\ninrecursive");
	qiga(CH,cluster_num,N,L,temp_mod1);
	FILE *fp3;

	fp3=fopen("out.txt","w");
	if(!fp3)
		printf("\nError");
	//initialize2(L);
	int L1=count(best_classical,cluster_num,N);
	int L2=count(best_classical,next_num,N);
	
	printf("\nL1 :   %d\n",L1);
	printf("\nL2 :   %d\n",L2);
	int *f1 =(int*)malloc(L1 * sizeof(int));
	int *f2 =(int*)malloc(L2 * sizeof(int));
	int *CH3 =(int*)malloc(L1 * sizeof(int));
	int *CH4 =(int*)malloc(L2 * sizeof(int));
	//int *CH5 =(int*)malloc(L1 * sizeof(int));
	//int *CH6 =(int*)malloc(L2 * sizeof(int));
	//cluster_num=next_num;
	double **temp_mod3 =(double**)malloc(L1 * sizeof(double *));
	if(temp_mod3 == 0)
	{
		printf("\n error in best_sol malloc");
	   	exit(1);
	}
	for(i = 0; i < L1; i++) 
	{
	   temp_mod3[i] =(double*) malloc(L1* sizeof(double));
	   if(temp_mod3[i] == 0)
	   {
	   	printf("\n error in best_sol malloc");
	   	exit(1);
	   }
	}
	double **temp_mod4 =(double**)malloc(L2 * sizeof(double *));
	if(temp_mod4 == 0)
	{
		printf("\n error in best_sol malloc");
	   	exit(1);
	}
	for(i = 0; i < L2; i++) 
	{
	   temp_mod4[i] =(double*) malloc(L2* sizeof(double));
	   if(temp_mod4[i] == 0)
	   {
	   	printf("\n error in best_sol malloc");
	   	exit(1);
	   }
	}
	int temp1,temp2,val=0,val1=0;
	double max,temp,m3,m4,temp_mod;
	max=mod2;
	temp=mod2;
	temp1=cluster_num;
	temp2=next_num;
	temp_mod=fitness_val;
	for(i=0;i<N;i++)
	{
		if(best_classical[i]==temp1)
			f1[val++]=i;
		else//if(CH[i]==cluster_num)
			continue;//f2[val1++]=i;
	}
	for(i=0;i<N;i++)
	{
		if(best_classical[i]==temp2)
			f2[val1++]=i;
		else//if(CH[i]==cluster_num)
			continue;//f2[val1++]=i;
	}
	for(i=0;i<L1;i++)
	{
		for(j=0;j<L1;j++)
		{
				temp_mod3[i][j]=temp_mod1[f1[i]][f1[j]];
		}
	}
	for(i=0;i<L2;i++)
	{
		for(j=0;j<L2;j++)
		{
				temp_mod4[i][j]=temp_mod1[f2[i]][f2[j]];
		}
	}
	for(i=0;i<L1;i++)
	{
		CH3[i]=best_classical[f1[i]];
	}
	for(i=0;i<L2;i++)
	{
		CH4[i]=best_classical[f2[i]];
	}
	m3=obj_func(CH3,temp_mod3,L1);
	m4=obj_func(CH4,temp_mod4,L2);
	/*printf("\nvalue of f1\n");
	for(j=0;j<L1;j++)
	{
		printf(" %d ",f1[j]);
	}
	printf("\nvalue of f2\n");
	for(j=0;j<L2;j++)
	{
		printf(" %d ",f2[j]);
	}
	printf("\nvalue of CH3\n");
	for(j=0;j<L1;j++)
	{
		printf(" %d ",CH3[j]);
	}
		printf("\nvalue of CH4\n");
	for(j=0;j<L2;j++)
	{
		printf(" %d ",CH4[j]);
	}*/
	/*printf("\nIntermediate solution");
	for(j=0;j<N;j++)
	    printf(" %d ", CH[j]);*/
 /*free(f1);
    free(f2);
   
    if(temp_mod>temp)
	{
		
		printf("\ni mmmm hereeeee\n");
		mod2=fitness_val;
		for(i=0;i<N;i++)
	    {
			CH[i]=best_classical[i];
	    }
        free(best_classical);

		if(L1>0)
		{
		
		m3=recursive_QGA(CH3,temp1,m3,L1,L1,temp_mod3);
		free(temp_mod3);
		free(CH3);
	    }
		if(L2>0)
		{
		
		m4=recursive_QGA(CH4,temp2,m4,L2,L2,temp_mod4);
		free(CH4);
			free(temp_mod4);
		}
	}
	mod2=m3+m4;
//	for(i=0;i<L1;i++)
	{
	//	CH[f1[i]]=CH3[i];
	}
//	for(i=0;i<L2;i++)
	{
	//	CH[f2[i]]=CH4[i];
	}
	
    printf("\nModularity : %f",mod2);
   
   // free(CH3);
    //free(CH4);
    //printf("\n\nN: %d ",N);
	//for(j=0;j<N;j++)
	  //  fprintf(fp3,"%d ",CH[j]);
	  //for(j=0;j<N;j++)
	    //printf("%d ",CH[j]);  
	fclose(fp3);
	return mod2;
}*/


double recursive_QGA(int *CH,int cluster_num,double mod2,int N,int L,double **temp_mod1)
{
     printf("\nIn recursive next_num : %d cluster_num %d",next_num,cluster_num);
	/*for(int i=0;i<N;i++)
		for(int j=0;j<N;j++)
			printf("\n btemp: %f",B[i*N+j]);*/
	
	int i;
	double mod_best;
	int temp_num=0;
	//printf("\nmod_best: %f,In recursive QGA, L=%d\n",*mod_best, L);
	int chng1=0,chng2=0;
      int next_num1;
	//int * next_num1= (int *)malloc(sizeof(int));
	//int* d_out1;
	//double *b_out1,*dd_mod;
//cudaError_t  err=cudaGetLastError();

//	double *max=(double*)malloc(sizeof(double));
//	if(!max)
//		printf("\nError in allocation");

	int *CHtemp=(int*)malloc(N*sizeof(int));
	/*for(int i=0;i<Ntemp;i++)
		CHtemp[i]=0;*/
	if(!CHtemp)
		printf("\nError in allocation");
 	
	for (i=0; i<N; i++)
      	CHtemp[i]=CH[i];

	
	
 
	
	//int nBlkTmp0=N/maxTxPerBlk;
    //	int maxBx= (N-nBlkTmp0 * maxTxPerBlk >0)? nBlkTmp0+1:nBlkTmp0;
	mod_best=mod2;
   	//printf("\n ************start qga");
   //	qiga_g(CHtemp,max);
   		mod_best=qiga(CHtemp,cluster_num,N,L,temp_mod1);

         printf("\n1 partition no of mutation = %d , %d", mut, mut2);

	//__syncthreads();
	int j=0,k=0;
	//printf("\n after qga");
	//*g_out=0.0;
//	for(i=0;i<N;i++)
	//  printf("%d ",CHtemp[i]);
         
	//printf("\n\ninto recursive qiga Ntemp: %d,next_num : %d,cluster_num: %d,L: %d,mod_best: %f\n ",Ntemp,*next_num,cluster_num,L,*mod_best);
	
	next_num1=next_num;
	temp_num=next_num1;	
	j=0; k=0;
    	for (i=0; i<N; i++){
        if (CHtemp[i]==cluster_num) j++;
        else if (CHtemp[i]==next_num1) k++;
    	}

	//printf("\n***CH1 n CH2 initialised");
	 
       // printf("\n \nj = %d, k = %d, max=%f, modbest=%f",j,k,*max,*mod_best);
       
       printf("\n j = %d , k = %d",j,k);
	
	if ((j!=0 && k!=0) && mod_best > mod2){

		printf("\nin if");
		for (i=0; i<N; i++)
  	    		CH[i]=CHtemp[i];
		/*for (i=0; i<N; i++)
			CH[i]=CHtemp[i];*/
		mod2=mod_best;
	//	free(CHtemp);
//
	//	printf("L=%d, cluster=%d, next=%d, split into %d and %d nodes\n", L, cluster_num, *next_num1, j,k);
		
		if ((j >1)){
		       	chng1=1;
	 //	printf("\nCalling left recursion");
			
			
			        // rec_modularity(CH,B,Ntemp,&g_out1[0]);
			  printf("\n\nright\n\n");
			
	            recursive_QGA(CH, cluster_num, mod2, N, L, temp_mod1);
	            	/*if (err!=cudaSuccess)
			printf("recursive2: cuda err=%s\n",cudaGetErrorString(err));
		__syncthreads();
		cudaDeviceSynchronize();*/
			
		//	printf("\n mod1=%f",*mod1);
		//	printf("\nchangd CH after left recursion: ");
    	//		for (i=0; i<Ntemp; i++)
		//	 printf("\nchanged %d ", CH[i]);
			//printf("\n");
		}
		if ((k >1)){
		       	chng2=1;
			//printf("\nCalling right recursion");
		
			
			/*cudaMemcpy(d_out2, CH, Ntemp * sizeof(int), cudaMemcpyHostToDevice);
			cudaMemcpy(b_out2, B, Ntemp * Ntemp * sizeof(double), cudaMemcpyHostToDevice);
			cudaMemcpy(d_mod1, g_out1, sizeof(double), cudaMemcpyHostToDevice);
		    	g_modularity<<<1,1>>>(CH,B,Ntemp,&g_out1[0],rec_mod[0]);
				//modularity(B1, Ntemp, &PT_tmp[i*Ntemp]);
			if (err!=cudaSuccess)
				printf("modularity: cuda err=%s\n",cudaGetErrorString(err));
			//__syncthreads();
			cudaDeviceSynchronize();
			cudaMemcpy(CH, d_out2, Ntemp * sizeof(int), cudaMemcpyDeviceToHost);
			cudaMemcpy(B, b_out2, Ntemp * Ntemp * sizeof(double), cudaMemcpyDeviceToHost);
			cudaMemcpy(g_out1, d_mod1, sizeof(double), cudaMemcpyDeviceToHost);
			//*mod2=*g_out2;
			//for (i=0;i<Ntemp;i++)
				//printf("\nbefore mod ch[i]=%d",CH[i]);

			//mod1=modularity(Btemp, Ntemp, CH);
			//		printf("\nIn recur: mod of 1st chromosomes: %f\n", *mod2);
	                //free(CHtemp);
			//free(g_out);
			//free(CHtemp);
			//free(CH1Idx);
			//free(CH2Idx);
			//free(mod1);
			//free(mod2);*/
			printf("\n\nleft\n\n");
			recursive_QGA(CH, temp_num, mod2, N, L, temp_mod1);
	            //	recursive(CH, Ntemp, rec_mod, next_num, temp_num, B, k);
	            	/*if (err!=cudaSuccess)
			printf("recursive1: cuda err=%s\n",cudaGetErrorString(err));
		__syncthreads();
		cudaDeviceSynchronize();*/
			//printf("changd CH after right recursion: ");
			//printf("\n mod2=%f",*mod2);
    			//for (i=0; i<Ntemp; i++)
			// printf("\nchanged%d ", CH[i]);
			//printf("\n");
		}
		//printf("mod_best=%f + %f = %f\n", *mod1, *mod2, *mod1+*mod2);
		
			if((chng1==1) || (chng2==1))
			{
			/**g_out1=0;
			cudaMemcpy(d_out3, CH, Ntemp * sizeof(int), cudaMemcpyHostToDevice);
			cudaMemcpy(b_out3, B, Ntemp * Ntemp * sizeof(double), cudaMemcpyHostToDevice);
			cudaMemcpy(d_mod3, g_out1, sizeof(double), cudaMemcpyHostToDevice);
		    	g_modularity<<<1,1>>>(CH,B,Ntemp,&g_out1[0],rec_mod[0]);
				//modularity(B1, Ntemp, &PT_tmp[i*Ntemp]);
			if (err!=cudaSuccess)
				printf("modularity: cuda err=%s\n",cudaGetErrorString(err));
			//__syncthreads();
			cudaDeviceSynchronize();
			cudaMemcpy(CH, d_out3, Ntemp * sizeof(int), cudaMemcpyDeviceToHost);
			cudaMemcpy(B, b_out3, Ntemp * Ntemp * sizeof(double), cudaMemcpyDeviceToHost);
			cudaMemcpy(g_out1, d_mod3, sizeof(double), cudaMemcpyDeviceToHost);
			*mod_best=0;
			*mod_best=rec_mod[0];*/
			if(mod2 < mod_best){
			  for (i=0; i<N; i++)
                		CH[i]=CHtemp[i];
            		//*mod_best=*max;
            		mod2=mod_best;
        		}
		}
		
		
		
		
	//printf("\n one recursion complete");		
	
   }
	
	//free(CH1Idxtmp);
	//free(CH2Idxtmp);
//	free(CHtemp);

//	free(next_num1);
	
	//printf("\n\nstructure\n\n");
	//for(i=0;i<N;i++)
	  // printf("%d ", CH[i]); 
/*else
{
	printf("\n#############*******^^^^^If not working");
}*/
	//free(CH1Idx);
	//free(CH2Idx);
	/*cudaFree(d_out1);
	cudaFree(d_out2);
	cudaFree(b_out1);
	cudaFree(b_out2);
	cudaFree(d_mod);
	cudaFree(d_mod1);*/
	printf("\n FINAL OUTPUT %f  %f",mod2,mod_best);
}
	
	
	
	





void qiga_main()
{
	int i;
//	double modval1;
	cluster_num=next_num;
	//ini(noOfNodes);
	ini_mod();	
//	printf("\ndone inimod");//for temp_mod1
	int *CH =(int*)malloc(noOfNodes * sizeof(int *));
	for(i=0;i<noOfNodes;i++)
		CH[i]=0;
	mod2=obj_func(CH,temp_mod1,noOfNodes);
	//printf("\ndone mod2");
	//printf("\nInitial modularity %f",mod);
	//printf("mod2 in qiga main:  %f",mod2);
	//compute mod_temp1 which is globally declade
	
   recursive_QGA(CH,cluster_num,mod2,noOfNodes,noOfNodes,temp_mod1);
  // printf("\nModularity : %f",mod2);
   free(temp_mod1);
    //qiga(CH,cluster_num,noOfNodes,noOfNodes,temp_mod1);
    /*for(int j=0;j<noOfNodes;j++)
	    printf(" %d ", best_classical[j]);*/
	
}
int main1()
{
    noOfChromosomes=0;
	noOfNodes=0;noOfEdges=0;nc=0;generations=0;alpha=0;beta=0;no_gen=0;
chromosomes=NULL; best_quantum=NULL; fitness_val=0; temp_mod1=NULL;
classical_pop =NULL;  degree=NULL;best_classical=NULL;tempChromosome=NULL;
 next_num=0;cluster_num=0;
// mod2,theta1,theta2,modval1;
	int msec = 0;
	int ctr=0,ctr2=0;
	int i,j,nodes1;
	double modval;
    clock_t time_elapsed = clock();
	FILE *fp;
	FILE *fp1;
	//int x[100];	
	
	//int x[]={5, 4, 4, 2, 4, 2, 1, 3, 2, 3, 4, 4, 2, 3, 2, 3, 3, 1, 5, 4, 4, 5, 5, 1, 2, 1, 4, 2, 5, 2, 1, 3, 4, 2, 3, 5, 5, 1, 2, 2, 3, 5, 1, 2, 2, 2, 3, 5, 3, 4, 3, 1, 2, 1, 3, 5, 1, 2, 3, 5, 4, 2, 2, 1, 5, 2, 2, 3, 1, 2, 4, 5, 3, 5, 5, 4, 1, 4, 1, 1, 2, 2, 4, 2, 1, 5, 1, 5, 5, 1, 1, 4, 4, 4, 5, 5, 2, 2, 4, 4};
	//int x[]={5, 3, 4, 5, 2, 1, 4, 2, 2, 4, 5, 6, 2, 4, 6, 3, 6, 3, 1, 5, 6, 2, 6, 6, 1, 5, 1, 2, 3, 2, 4, 4, 3, 1, 3, 4, 3, 2, 2, 5, 5, 6, 1, 6, 5, 1, 3, 5, 4, 3, 4, 1, 5, 4, 3, 5, 3, 6, 2, 1, 3, 2, 5, 6, 6, 3, 4, 2, 6, 1, 6, 5, 3, 5, 3, 1, 4, 1, 5, 4, 4, 5, 1, 4, 5, 5, 4, 4, 6, 5, 6, 1, 6, 5, 4, 1, 6, 6, 4, 4};
	//int x[]={1,3,2,1,5,4,3,1,4,1,4,4,4,1,2,4,3,5,2,1,1,1,4,1,2,4,3,5,1,4,2,5,1,5,1,1,1,2,4,1,4,4,1,5,2,2,5,5,2,1,1,1,4,5,5,1,1,3,2,3,5,3,1,2,4,1,5,5,4,1,1,5,5,1,4,1,3,4,3,4,3,3,1,1,1,5,3,2,4,2,3,3,2,2,3,1,2,5,3,1,3,2,3,2,4,4,4,5,5,5,3,4,5,2,1,5,1,4,1,2,3,3,2,1,1,3,4,1,1,5,2,3,5,1,2,5,1,5,4,1,3,3,1,5,1,4,3,1,5,5,1,1,4,3,4,4,1,5,1,2,4,3,3,2,4,4,5,4,2,4,3,5,3,5,3,1,3,4,1,2,1,5,4,5,3,4,2,3,2,2,5,5,1,1,5,1,2,1,5,4};
	char filename[50];
	
	srand(time(NULL));
	fp = fopen("parameter1.txt", "r");
	if(fp == NULL)
    {
	   printf("\nparamete File could not be opened in read mode!!!\n");
	   return 1;
    }
    nc=2;
    fscanf(fp,"%d",&noOfChromosomes);
    fscanf(fp,"%s",&filename);
    fscanf(fp,"%lf",&theta3);
	fscanf(fp,"%lf",&theta2);
    fscanf(fp,"%d",&alpha);
	fscanf(fp,"%d",&beta);
    fscanf(fp,"%d",&generations);
    fscanf(fp,"%lf",&MutRate);
    fclose(fp);
 theta1 =0.00;
theta4 =0.0;
theta5 =-1 * theta3;
theta6 =-0.0;
theta7 =0.00;
theta8 =-1 * theta2;
    /*
    fp1=fopen("nsgavar.txt","r");
    if(fp == NULL)
    {
	   printf("\nnsgavar File could not be opened in read mode!!!\n");
	   return 1;
    }*/
//	fscanf(fp1,"%lf",&theta1);
//	fscanf(fp1,"%lf",&theta2);
	 // fclose(fp1);  
   //printf("theta1 : %lf\ntheta2 : %lf\nalpha : %d\nbeta : %d\n ",theta1,theta2,alpha,beta);
   // printf("\n %d",noOfChromosomes);
    //printf("\n %s",filename);
    //printf("\n%f",theta1);
    //printf("\n%f",theta2);
    //printf("\n%d",alpha);
     //printf("\n%d",beta);
    //printf("\n %d",generations);
    noOfNodes=NoOfNodesF(filename);
   // cluster_num=next_num;
  

        qiga_main();
   
    
    //*result=fmod1; 
     //printf("\nModularity in main : %f",*result);
    //ini_mod();
    //mod2=modval1;    
    //	m=obj_func(x,temp_mod1,noOfNodes);
    	
    //printf("\n\nm: %f",m);
    	printf("\n\n\noverall no of generations including recursive calls : %d",nogen);
    
	    printf("no of mutation = %d", mut);
    //free(classical_pop);
    //free(chromosomes);
    free(tempChromosome);
  // initialize2();
	// free(mod);

	//measure2();
    
	
	
  // free(best_quantum);
	//free(best_classical);
   
	free(degree);
   //printf("Modularity Value: %f",modval);
	//qiga2();*/
	time_elapsed = clock() - time_elapsed;
	msec = time_elapsed * 1000 / CLOCKS_PER_SEC;
	printf("\n\n\n\ntest1=%d",test1);
	printf("\nTime taken %d seconds %d milliseconds\n",msec/1000, msec%1000);
	return 0;
}

int main()
{
  int i=0;
  for(i=0;i<1;i++)
    {
       printf("\n\n\n ************iteration = %d**************\n\n\n",i+1);
       main1();
     }  
return 0;
}

