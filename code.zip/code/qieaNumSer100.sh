cat <<EOF > parameter2.txt
15
100_1adj.txt
0.095
0.0058
0.01
0.005
2000
0.13
11
EOF


gcc -o lfrqiea100 qieaNumChromosome.c -lm
./lfrqiea100 


