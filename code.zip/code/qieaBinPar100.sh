 #!/bin/bash         


cat <<EOF > parameter3.h
#define N 100
#define filename "data//100_12adj.txt"
#define filenameB "B//100_12adjB.txt"
#define filenameDeg "Deg//100_12adjDeg.txt"
#define mutProb 0.3
#define popSize 15
#define maxGenerations 2000
#define maxTxPerBlk 128
const float theta1 =0.00, theta2 =0.001, theta3 =0.085, theta4 =0.0, theta5 =-0.085, theta6 =-0.0, theta7 =0.00, theta8 =-0.001;
EOF

/usr/local/cuda-8.0/bin/nvcc -rdc=true -lcudadevrt -arch=sm_35 -o qiga100 qieaBinChromosome.cu -lineinfo

./qiga100 

