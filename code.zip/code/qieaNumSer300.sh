#!/bin/bash

cat <<EOF > parameter2.txt
15
300_15adj.txt
0.095
0.0058
0.01
0.005
4000
0.13
9
EOF

gcc -o lfrqiea300 qieaNumChromosome.c -lm
./lfrqiea300 

