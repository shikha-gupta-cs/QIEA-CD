 #!/bin/bash         

cat <<EOF > parameter3.h
#define N 300
#define filename "data//lfr300_1.txt"
#define filenameB "B//lfr300_1B.txt"
#define filenameDeg "Deg//lfr300_1Deg.txt"
#define mutProb 0.3
#define popSize 15
#define maxGenerations 6000
#define maxTxPerBlk 512
const float theta1 =0.00, theta2 =0.001, theta3 =0.085, theta4 =0.0, theta5 =-0.085, theta6 =-0.0, theta7 =0.00, theta8 =-0.001;
EOF

/usr/local/cuda-8.0/bin/nvcc -rdc=true -lcudadevrt -arch=sm_35 -o qiga300 qieaBinChromosome.cu -lineinfo

 ./qiga300 
 