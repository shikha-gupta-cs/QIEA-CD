 #!/bin/bash         

cat <<EOF > parameter4.h
#define N 300
#define filename "data//lfr300_1.txt"
#define filenameB "B//lfr300_1B.txt"
#define filenameDeg "Deg//lfr300_1Deg.txt"
#define mutRate 0.3
#define popSize 15
#define maxGenerations 6000
#define maxTxPerBlk 512
#define alpha 0.01
#define beta 0.005
#define nc 10
const float theta1 =0.095;
const float theta2 =0.0058;
EOF

/usr/local/cuda-8.0/bin/nvcc -rdc=true -lcudadevrt -arch=sm_35 -o qiea300 qieaNumChromosome.cu -lineinfo

 ./qiea300
 
