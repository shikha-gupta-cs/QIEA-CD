#!/bin/bash

cat <<EOF > parameter1.txt
10
300_1adj.txt
.085
.001
10
40
8000
.15
EOF

gcc -o lfrqiga300 qieaBinChromosome.c -lm
./lfrqiga300 

